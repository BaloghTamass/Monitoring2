﻿using System.Windows;
using System.Management;
//using System.Generic.Maths.Win32&64;
//using.Using.Gabiegymeleg

namespace Monitoring2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public void CPU()
        {
            ManagementObjectSearcher cpu = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Processor");
            foreach (var cpu2 in cpu.Get())
            {
                cpuname.Content = cpu2["Name"];
                cpucores.Content = cpu2["NumberOfCores"];
            }
        }
        public void GPU()
        {
            ManagementObjectSearcher gpu = new ManagementObjectSearcher("root\\CIMV2",  "SELECT * FROM Win32_VideoController");
            foreach (var gpu2 in gpu.Get())
            {
                gpuname.Content = gpu2["Name"];
                gpuram.Content = gpu2["AdapterRAM"];
            }
        }
    }
}
